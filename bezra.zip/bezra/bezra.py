import cv2
import numpy as np
import paho.mqtt.client as mqtt

cap = cv2.VideoCapture(0)

client = mqtt.Client()
client.connect("192.168.11", 1883, 60)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Resize frame to reduce bandwidth (optional)
    frame = cv2.resize(frame, (640, 480))

    # Encode frame as JPEG
    _, buffer = cv2.imencode('.jpg', frame)
    data = buffer.tobytes()

    client.publish("video_stream", data, qos=1)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
