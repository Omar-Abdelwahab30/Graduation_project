import wx
import cv2
import numpy as np
import serial
import platform
import subprocess

# Constants
SERIAL_PORT = '/dev/cu.usbmodem21101'  # Example serial port, replace with your actual port
BAUD_RATE = 9600
CAMERA_INDEX = 0  # Index of the camera, typically 0 for the built-in camera

class LoginFrame(wx.Frame):
    def __init__(self, parent, title):
        super(LoginFrame, self).__init__(parent, title=title, size=(300, 150))
        
        self.panel = LoginPanel(self)
        self.Show()

class LoginPanel(wx.Panel):
    def __init__(self, parent):
        super(LoginPanel, self).__init__(parent)
        
        self.username_text = wx.TextCtrl(self, style=wx.TE_PROCESS_ENTER)
        self.password_text = wx.TextCtrl(self, style=wx.TE_PASSWORD | wx.TE_PROCESS_ENTER)
        login_button = wx.Button(self, label="Login")
        login_button.Bind(wx.EVT_BUTTON, self.on_login_button_click)
        
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(wx.StaticText(self, label="Username:"), 0, wx.ALL, 5)
        sizer.Add(self.username_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(wx.StaticText(self, label="Password:"), 0, wx.ALL, 5)
        sizer.Add(self.password_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(login_button, 0, wx.ALIGN_CENTER | wx.ALL, 5)
        
        self.SetSizer(sizer)

    def on_login_button_click(self, event):
        username = self.username_text.GetValue()
        password = self.password_text.GetValue()
        if username == "robot" and password == "123":
            self.GetParent().Hide()
            main_frame = MainFrame(None, "Robot Control and Live Video Stream")
            main_frame.Show()
        else:
            wx.MessageBox("Invalid username or password.", "Login Failed", wx.OK | wx.ICON_ERROR)

class MainFrame(wx.Frame):
    def __init__(self, parent, title):
        super(MainFrame, self).__init__(parent, title=title, size=(800, 600))
        
        splitter = wx.SplitterWindow(self)
        self.video_panel = VideoPanel(splitter)
        self.control_panel = ControlPanel(splitter)
        
        splitter.SplitVertically(self.video_panel, self.control_panel)
        splitter.SetSashGravity(0.5)  # Set initial position of the splitter
        
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(splitter, 1, wx.EXPAND)
        self.SetSizer(sizer)
        
        self.Show()

class VideoPanel(wx.Panel):
    def __init__(self, parent):
        super(VideoPanel, self).__init__(parent)
        self.video_display = wx.StaticBitmap(self)
        self.capture = cv2.VideoCapture(CAMERA_INDEX)
        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.on_update_video, self.timer)
        self.timer.Start(1000 // 24)  # Update every 24 frames per second
        
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.video_display, 1, wx.EXPAND)
        self.SetSizer(sizer)

    def on_update_video(self, event):
        ret, frame = self.capture.read()
        if ret:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w = frame.shape[:2]
            bitmap = wx.Bitmap.FromBuffer(w, h, frame)
            self.video_display.SetBitmap(bitmap)

    def __del__(self):
        self.timer.Stop()
        self.capture.release()

class ControlPanel(wx.Panel):
    def __init__(self, parent):
        super(ControlPanel, self).__init__(parent)
        forward_button = wx.Button(self, label="Forward")
        forward_button.Bind(wx.EVT_BUTTON, lambda event: print("Forward"))
        backward_button = wx.Button(self, label="Backward")
        backward_button.Bind(wx.EVT_BUTTON, lambda event: print("Backward"))
        left_button = wx.Button(self, label="Left")
        left_button.Bind(wx.EVT_BUTTON, lambda event: print("Left"))
        right_button = wx.Button(self, label="Right")
        right_button.Bind(wx.EVT_BUTTON, lambda event: print("Right"))
        temp_label = wx.StaticText(self, label="Temperature:")
        pressure_label = wx.StaticText(self, label="Pressure:")

        sizer = wx.GridSizer(3, 2, 5, 5)
        sizer.Add(forward_button, 0, wx.ALL, 5)
        sizer.Add(backward_button, 0, wx.ALL, 5)
        sizer.Add(left_button, 0, wx.ALL, 5)
        sizer.Add(right_button, 0, wx.ALL, 5)
        sizer.Add(temp_label, 0, wx.ALL, 5)
        sizer.Add(pressure_label, 0, wx.ALL, 5)

        self.SetSizer(sizer)

if __name__ == '__main__':
    app = wx.App()
    login_frame = LoginFrame(None, "Login")
    app.MainLoop()
