import wx
import cv2
import numpy as np
import socket
import base64
import time

BUFF_SIZE = 65536

class MainFrame(wx.Frame):
    def __init__(self, parent, title):
        super(MainFrame, self).__init__(parent, title=title, size=(800, 600))
        
        splitter = wx.SplitterWindow(self)
        self.video_panel = VideoPanel(splitter)
        self.control_panel = ControlPanel(splitter)
        
        splitter.SplitVertically(self.video_panel, self.control_panel)
        splitter.SetSashGravity(0.5)  # Set initial position of the splitter
        
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(splitter, 1, wx.EXPAND)
        self.SetSizer(sizer)
        self.Show()

class VideoPanel(wx.Panel):
    def __init__(self, parent):
        super(VideoPanel, self).__init__(parent)

        self.video_display = wx.StaticBitmap(self)
        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, self.update_video_frame, self.timer)
        self.timer.Start(1000 // 15)  # Update every 15 frames per second

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.video_display, 1, wx.EXPAND)
        self.SetSizer(sizer)

        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, BUFF_SIZE)
        self.host_ip = '192.168.1.17'
        self.port = 9999
        self.message = b'Hello'

        self.client_socket.sendto(self.message, (self.host_ip, self.port))
        self.fps = 0
        self.start_time = time.time()

    def update_video_frame(self, event):
        try:
            packet, _ = self.client_socket.recvfrom(BUFF_SIZE)
            data = base64.b64decode(packet)
            npdata = np.frombuffer(data, dtype=np.uint8)
            frame = cv2.imdecode(npdata, 1)
            if frame is not None:
                frame = cv2.putText(frame, 'FPS: ' + str(self.fps), (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

                h, w = frame.shape[:2]
                bitmap = wx.Bitmap.FromBuffer(w, h, frame)
                self.video_display.SetBitmap(bitmap)

                # Update FPS
                self.fps = round(1 / (time.time() - self.start_time))
                self.start_time = time.time()
        except Exception as e:
            print("Error receiving frame:", e)

    def __del__(self):
        self.timer.Stop()
        self.client_socket.close()

class ControlPanel(wx.Panel):
    def __init__(self, parent):
        super(ControlPanel, self).__init__(parent)
        forward_button = wx.Button(self, label="Forward")
        forward_button.Bind(wx.EVT_BUTTON, lambda event: print("Forward"))
        backward_button = wx.Button(self, label="Backward")
        backward_button.Bind(wx.EVT_BUTTON, lambda event: print("Backward"))
        left_button = wx.Button(self, label="Left")
        left_button.Bind(wx.EVT_BUTTON, lambda event: print("Left"))
        right_button = wx.Button(self, label="Right")
        right_button.Bind(wx.EVT_BUTTON, lambda event: print("Right"))
        temp_label = wx.StaticText(self, label="Temperature:")
        pressure_label = wx.StaticText(self, label="Pressure:")

        sizer = wx.GridSizer(3, 2, 5, 5)
        sizer.Add(forward_button, 0, wx.ALL, 5)
        sizer.Add(backward_button, 0, wx.ALL, 5)
        sizer.Add(left_button, 0, wx.ALL, 5)
        sizer.Add(right_button, 0, wx.ALL, 5)
        sizer.Add(temp_label, 0, wx.ALL, 5)
        sizer.Add(pressure_label, 0, wx.ALL, 5)

        self.SetSizer(sizer)

if __name__ == '__main__':
    app = wx.App()
    main_frame = MainFrame(None, "Robot Control and Live Video Stream")
    app.MainLoop()
