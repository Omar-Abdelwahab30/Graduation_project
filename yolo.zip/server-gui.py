import cv2
import socket
import base64

BUFF_SIZE = 65536
CHUNK_SIZE = 1024  # Adjust as needed

# Server configuration
host_ip = '192.168.1.8'  # Replace with the server's IP address
port = 9999

# Initialize socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, BUFF_SIZE)

# Initialize video capture
cap = cv2.VideoCapture(0)  # Use 0 for the default webcam

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Encode frame
        _, buffer = cv2.imencode('.jpg', frame)
        data = base64.b64encode(buffer)

        # Send frame over UDP in chunks
        for i in range(0, len(data), CHUNK_SIZE):
            chunk = data[i:i+CHUNK_SIZE]
            server_socket.sendto(chunk, (host_ip, port))

        # Check for key press to stop streaming
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except Exception as e:
    print(f"Error: {e}")

finally:
    # Close the socket and release the video capture
    server_socket.close()
    cap.release()
