import rclpy
from std_msgs.msg import String

def callback(msg):
    print(f"Received: {msg.data}")

def subscriber_node():
    rclpy.init()
    node = rclpy.create_node('subscriber_node')
    subscriber = node.create_subscription(String, 'chatter', callback, 10)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("Shutting down subscriber_node")
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    subscriber_node()
