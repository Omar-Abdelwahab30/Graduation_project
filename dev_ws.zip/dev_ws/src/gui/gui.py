import sys
from PyQt5.QtWidgets import QApplication, QLabel, QVBoxLayout, QWidget,QPushButton
import threading
import subprocess
def start_publisher():
    subprocess.run(['python3', 'publisher_node.py'])

def start_subscriber():
    subprocess.run(['python3', 'subscriber_node.py'])

app = QApplication(sys.argv)

window = QWidget()
window.setWindowTitle("ROS 2 GUI Example")

layout = QVBoxLayout()

label = QLabel("ROS 2 GUI Example")
layout.addWidget(label)

start_publisher_button = QPushButton("Start Publisher")
start_publisher_button.clicked.connect(start_publisher)
layout.addWidget(start_publisher_button)

start_subscriber_button = QPushButton("Start Subscriber")
start_subscriber_button.clicked.connect(start_subscriber)
layout.addWidget(start_subscriber_button)

window.setLayout(layout)

window.show()
sys.exit(app.exec_())
